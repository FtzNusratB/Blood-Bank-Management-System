<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="style.css">

</head>
<body>

<div class="navbar">
  <div class="dropdown">
    <button class="dropbtn">My Profile
      <i class="arrow down"></i>
    </button>
    <div class="dropdown-content">
      <a href="VIEW PROFILE.php">View Profile</a>
      <a href="EDIT PROFILE.php">Edit Profile</a>
      <a href="PROFILE PICTURE.php">Change Profile Picture</a>
      <a href="CHANGE PASSWORD.php">Change Password</a>
    </div>
  </div>

  <div class="dropdown">
    <button class="dropbtn">Blood Donation
      <i class="arrow down"></i>
    </button>
    <div class="dropdown-content">
      <a href="ENTER BLOOD.php">New donor</a>
      <a href="ENTER OLD DONOR.php">Old donor</a>
    </div>
  </div>

  <div class="dropdown">
    <a href = "SEARCH BLOOD.php" class="dropbtn">My Profile</a>
  </div>
</div>
</body>
</html>