<!DOCTYPE html>
<html>
<head>



</head>

<body>
<div class="row">
<div class="column">
<h2>Blood Bank Management System</h2></p>
</div>
    <form action="profile.php"><button type="submit" name="submit" class="profilee">Profile</button></form>
    <form action="logout1.php"><button type="submit" name="submit" class="profilee">Logout</button></form>
</div>
<hr>
</body>
</html>
