<footer>
<hr>
<center><div><?php
echo "<p>Copyright © " . date("Y") . "</p>";
?></div>
</center>
</footer>