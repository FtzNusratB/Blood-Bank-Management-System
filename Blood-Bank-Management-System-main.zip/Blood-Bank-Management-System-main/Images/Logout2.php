<?php 

session_start();

	session_destroy();
	header("location:../Login2.php");
	

?>