<html>
<body>


<span style = "display:inline-block; width:100%; height:10%; text-align:center;">
<div class="footer">  
<?php
echo "<p>Copyright By BBMS</p>";
?>
</span> 

</div>
</body>
</html>