<html>
<body>

<?php include 'header.php';?>

<span style = "display:inline-block; width:100%;text-align:left; height: 30%; padding:10px">
<?php
echo "<h3>Welcome to Bangladesh Blood Bank</h3></p>";
?>
</span> 

<?php include 'footer.php';?>

</body>
</html>