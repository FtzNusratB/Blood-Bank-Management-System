<?php

require_once 'Model/model2.php';

function fetchAllpatient(){
	return showAllpatient();

}
function fetchPatient($username){
	return showPatient($username);

}
?> 