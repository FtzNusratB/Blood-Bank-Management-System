<html>
<head>
  <link rel="stylesheet" type="text/css" href="style.css">
  <script type="text/javascript" src ="js/footer.js"></script>
</head>
<body>

<div class="row">
  <div class="column1" >
    <div id="contact">
      
    </div>
  </div>
  <div class="column1 alignLeft" >
    News and Stories<br>
    About Us<Br>
    <p onclick="showContact()">Contact Us</p> <br>
  </div>
  <div class="column1 alignLeft" >
    Privacy policy<br>
    Terms of Service<br>
  </div>
  <div class="column1 " >
    
  </div>
  
</div>
<span class="footer">
<?php
echo "<p>&copy; Bangladesh Red Crescent Society</p>";
?>
</span> 


</body>
</html>